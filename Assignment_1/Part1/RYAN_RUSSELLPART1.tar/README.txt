Name: Ryan Russell
UIN: 227006614
Section: 511
Username: rhrussell
Email: rhrussell@tamu.edu
I certify that I have listed all the sources that I used to develop the solutions and code to the
submitted work.
On my honor as an Aggie, I have neither given nor received any unauthorized help
on this academic work.
Ryan Russell 	1/22/2020

One of the problems that I had with the program is that the test file would not work properly
with my code. This problem is now fixed.

When it came to testing my code, everytime I finished a part of the assignment (i.e. a constructor,
a method, an overloaded operator), I would stop constructing anything new and test out the
new item I added to the program.