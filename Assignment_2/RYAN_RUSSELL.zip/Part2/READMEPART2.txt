Name: Ryan Russell
UIN: 227006614
Section Number: CSCE 221-511
Username: rhrussell
Email: rhrussell@tamu.edu

I certify that I have listed all the sources that I used to develop the solutions and code to the
submitted work.
On my honor as an Aggie, I have neither given nor received any unauthorized help
on this academic work.
Ryan Russell	2/28/2020

Resources:
None

No known problems

I tested my code for correctness by working on one part of the assignment one at a time
and then testing the method or part of the code to see if I got the expected result. If I
did not get those results I would try to break down the method or that part of the assignment
even further to figure out the problem. I used exceptions for error handling by throwing
obvious cases (i.e index out of bounds, removing an item that doesn't exist, removing an
item when the doubly linked list is empty) and if there were other cases that popped up in
the development process then I would incorporate them. Templating definitely was hard to
implement, but I was able to make the transition from the original code to templated 
version pretty easy. 